import time
import sys
import os
import datetime
import streamlit as st
from PIL import Image

page_bg_img = """
<style>
[data-testid="stAppViewContainer"]                              
{background-color:lightcyan}
[data-testid="stSidebar"]
{background-color: powderblue;}
</style>
"""
st.markdown(page_bg_img, unsafe_allow_html=True)


st.title(":blue[📚Selamat Datang Di Librata📚]")

daftarbuku= st.Page("./menu/daftarbuku.py", title="Daftar Buku")
peraturan= st.Page("./menu/peraturan.py", title="Peraturan Perpustakaan")
peminjaman1= st.Page("./menu/formpeminjamanbukufiksi.py", title="Peminjaman Buku Fiksi")
peminjaman2= st.Page("./menu/formpeminjamanbukunonfiksi.py", title="Peminjaman Buku Non Fiksi")
pengembalian1 = st.Page("./menu/formpengembalianbukufiksi.py", title="Pengembalian Buku Fiksi")
pengembalian2 = st.Page("./menu/formpengembalianbukunonfiksi.py", title="Pengembalian Buku Non Fiksi")
informasi = st.Page("./menu/informasi-pengguna.py", title="Informasi Pengguna")

pg = st.navigation(
    {
    "Menu Pengguna": [daftarbuku, informasi, peraturan],
    "Peminjaman Buku":[peminjaman1, peminjaman2], 
    "Pengembalian Buku":[pengembalian1, pengembalian2],
    })

pg.run()


