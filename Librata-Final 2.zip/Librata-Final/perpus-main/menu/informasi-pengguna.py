import time
import sys
import os
import datetime
import streamlit as st
from PIL import Image

if "form1" in st.session_state:
    form1 = st.session_state["form1"]
    st.write("Struk Bukti Pinjam Buku Fiksi")
    st.write(f"Nama: {form1['Nama']}")
    st.write(f"Judul: {form1['Judul']}")
    st.write(f"Tanggal Peminjaman: {form1['Tanggal Peminjaman']}")
    st.write(f"Tanggal Kembali: {form1['Tanggal Kembali']}")
    st.write("Terima Kasih Telah Meminjam Buku Ditempat Kami")
    st.write("Mohon untuk selalu menjaga buku yang telah dipinjam")
    st.write(":red[Struk Harap dibawa ketika ingin mengembalikan buku.]")

elif "form4" in st.session_state:
    form4 = st.session_state["form4"]
    st.write("Struk Bukti Pinjam Buku Nonfiksi")
    st.write(f"Nama: {form4['Nama']}")
    st.write(f"Judul: {form4['Judul']}")
    st.write(f"Tanggal Peminjaman: {form4['Tanggal Peminjaman']}")
    st.write(f"Tanggal Kembali: {form4['Tanggal Kembali']}")
    st.write("Terima Kasih Telah Meminjam Buku Ditempat Kami")
    st.write("Mohon untuk selalu menjaga buku yang telah dipinjam")
    st.write(":red[Struk Harap dibawa ketika ingin mengembalikan buku.]")

elif "form2" in st.session_state:
    form2 = st.session_state["form2"]
    st.write("Struk Bukti Pinjam ")
    st.write(f"Nama: {form2['Nama']}")
    st.write(f"Judul: {form2['Judul']}")
    st.write(f"Deadline Pengembalian: {form2['Tanggal Kembali']}")
    st.write("Terima Kasih Telah Meminjam Buku Ditempat Kami")
    st.write("Datang kembali ya >-<")

elif "form3" in st.session_state:
    form3 = st.session_state["form3"]
    st.write("Struk Bukti Pinjam ")
    st.write(f"Nama: {form3['Nama']}")
    st.write(f"Judul: {form3['Judul']}")
    st.write(f"Deadline Pengembalian: {form3['Tanggal Kembali']}")
    st.write("Terima Kasih Telah Meminjam Buku Ditempat Kami")
    st.write("Datang kembali ya >-<")

else:
    st.warning("Kamu belum meminjam buku.")
