import time
import sys
import os
import datetime
import streamlit as st


st.empty()
st.title("📖 Peminjaman Buku Fiksi")
st.write("Silahkan Masukkan Data Diri Anda. Pastikan buku yang anda pinjam sesuai dengan genre buku👌")
form1 = st.form(key="annotation1",clear_on_submit=True)
    

with form1:
        cols = st.columns((1,1))
        nama = cols[0].text_input("Nama Lengkap :")
        judul = cols[1].selectbox('Pilih Judul Buku',('','172 Days','A Kite For Moon','Amba','Angkasa dan 56 hari','Ayah','Brianna Dan Bottomwise','Cinta Brontosaurus','Dunia Maya','Fangirl','Fiksi Sains','The Strom We Made','Guru Aini','Kipas Angin','Koala Kumal','Misteri Pantai Muara','Oh My Savior','Pesan Terakhir','Planet Luna','rinjani','Segala Yang Diisap Langit','The Last Spell Breather'))
        cols = st.columns(2)
        tglpinjam = cols[0].date_input("Tanggal Peminjaman :")
        tglkembali = cols[1].date_input("Tanggal Kembali :")
        submitted = st.form_submit_button(label="Submit")


        if submitted:
            if "form1" not in st.session_state:
                 st.session_state["form1"] = {}
                 st.session_state["form1"] = {"Nama": nama, "Judul": judul, "Tanggal Peminjaman": tglpinjam, "Tanggal Kembali": tglkembali}
            st.success("Terimakasih sudah meminjam buku di perpustakaan Librata! Jangan lupa simpan struk peminjaman ya")
            st.balloons()
            