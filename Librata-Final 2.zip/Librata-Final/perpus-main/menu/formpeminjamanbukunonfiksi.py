import time
import sys
import os
import datetime
import streamlit as st

st.title("📖Peminjaman Buku Non Fiksi")
st.write("Silahkan Masukkan Data Diri Anda")
form4 = st.form(key="annotation1",clear_on_submit=True)
    

with form4:
        cols = st.columns((1,1))
        nama = cols[0].text_input("Nama Lengkap :")
        judul = cols[1].selectbox('Pilih Judul Buku',('','B.J.Habibie','Dari Penjara Ke Penjara','Ensiklopeddia Sejarah Dunia','Jika Kita Tak Pernah Jadi Apa-apa','Kamu Gak Sendiri','La Tahzan','Lima Cerita','Membaca Pikiran Orang','Pancasila','Resensi Buku Non Fiksi','The Great Gatsby by F. Scott Fitzgerald','To Kill a Mockingbird by Harper Lee','1984 by George Orwell','Pride and Prejudice by Jane Austen','The Catcher in the Rye by J.D. Salinger','Little Women by Lousia May Alcott','Poor Dad Rich Dad by Robert T. Kiyosaki','Atomic Habits by James Clear','Moby Dick by Herman Melvile','Sapiens by Yuval Noah Harari'))
        cols = st.columns(2)
        tglpinjam = cols[0].date_input("Tanggal Peminjaman :")
        tglkembali = cols[1].date_input("Tanggal Kembali :")
        submitted = st.form_submit_button(label="Submit")

        if submitted:
            if "form4" not in st.session_state:
                 st.session_state["form4"] = {}
                 st.session_state["form4"] = {"Nama": nama, "Judul": judul, "Tanggal Peminjaman": tglpinjam, "Tanggal Kembali": tglkembali}
            st.success("Terimakasih sudah meminjam buku di perpustakaan Librata! Jangan lupa simpan struk peminjaman ya")
            st.balloons()