import streamlit as st

st.header("Andre :blue[Apriyana] :sunglasses:")
st.title("Aplikasi Kalkulator Sederhana")

contoh1 = st.Page("./pages/file1.py", title="File 1")
contoh2 = st.Page("./pages/file2.py", title="File 2")
contoh3 = st.Page("./pages/file3.py", title="File 3")

pg = st.navigation(
    {
    "Menu Utama":[contoh1], 
    "Menu Lainnya":[contoh2],
    "Menu2" : [contoh3]
    })
print(type(pg))
pg.run()